/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.recursos;


/**
 *
 * @author Pc
 */
public class Recursos {

     // Primer método: Retornar un mensaje que diga "Programación Orientada a Objetos"
    public String obtenerMensaje() {
        return "Programacion Orientada a Objetos";
    }

    // Segundo método: Retornar si el estudiante es mayor o menor de edad según su edad
    public String verificarEdad(int edad) {
        if (edad >= 21) {
            return "Mayor de edad";
        } else {
            return "Menor de edad";
        }
    }

    // Tercer método: Retornar el resultado de la multiplicación de dos enteros
    public int multiplicar(int num1, int num2) {
        return num1 * num2;
    }

    // Cuarto método: Retornar una lista de números del 1 al X
    public int[] generarListaNumeros(int x) {
        int[] numeros = new int[x];
        for (int i = 0; i < x; i++) {
            numeros[i] = i + 1;
        }
        return numeros;
    }
 public static void main(String[] args) {
        // Instanciando la clase Recursos
        Recursos recursos = new Recursos();

        // Llamando al primer método
        System.out.println(recursos.obtenerMensaje());

        // Llamando al segundo método con una edad
        int edadEstudiante = 21; // Cambia el valor para probar diferentes edades
        System.out.println("Edad del estudiante: " + edadEstudiante + " - " + recursos.verificarEdad(edadEstudiante));

        // Llamando al tercer método (multiplicación)
        int num1 = 5;
        int num2 = 4;
        System.out.println("Multiplicacion de " + num1 + " y " + num2 + ": " + recursos.multiplicar(num1, num2));

        // Llamando al cuarto método (generar lista de números)
        int x = 10; // Cambia el valor de X para probar diferentes listas
        int[] listaNumeros = recursos.generarListaNumeros(x);
        System.out.print("Lista de numeros del 1 al " + x + ": ");
        for (int numero : listaNumeros) {
            System.out.print(numero + " ");
        }
    }
}




   

